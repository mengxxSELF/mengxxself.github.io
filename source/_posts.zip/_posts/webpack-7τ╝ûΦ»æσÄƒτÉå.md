---
title: webpack-7编译原理
date: 2018-02-03 23:31:48
categories: 前端自动化
tags: webpack
---

在webpack的构建流程中，功能通过发布订阅事件来触发各个插件的执行， 
