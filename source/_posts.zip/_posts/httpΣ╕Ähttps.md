---
title: http与https
date: 2017-11-06 14:03:12
tags:
---


在Internet中所有的传输都是通过TCP/IP进行的。HTTP协议作为TCP/IP模型中应用层的协议也不例外。HTTP协议通常承载于TCP协议之上，有时也承载于TLS或SSL协议层之上，这个时候，就成了我们常说的HTTPS。如下图所示：

<!--nore-->

![https](/img/http/https.png)

HTTP默认的端口号为80，HTTPS的端口号为443。
