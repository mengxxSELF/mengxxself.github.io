---
title: JavaScript零碎
date: 2017-11-06 15:25:07
categories: javascript
tags: [other]
---

JavaScript零碎知识点

<!--more-->

1 关于运算符

算数运算符：+ - * / %

比较运算符：< > <= >= == === != !==

逻辑运算符：&& || ！

运算符的优先级: 算数 > 比较 > 逻辑 > 赋值

2 if() 条件为真假

除了以下六个为假，其他都为真： false 0 “” null undefined NaN

4 JavaScript 基本数据类型

Undefined Null Number String Boolean
