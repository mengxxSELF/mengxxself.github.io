---
title: webpack文章记录
date: 2017-12-24 12:15:50
categories: 前端自动化
tags: webpack
---

## 文章

* [webpack的主要对象](https://github.com/renaesop/blog/issues/16)  

没看懂


## 源码

* [WebpackOptionsApply](https://github.com/webpack/webpack/blob/master/lib/WebpackOptionsApply.js#L70-L185)


## AST

抽象语法树（Abstract Syntax Tree）也称为AST语法树，指的是源代码语法所对应的树状结构。

也就是说，对于一种具体编程语言下的源代码，通过构建语法树的形式将源代码中的语句映射到树中的每一个节点上。

[AST](http://www.iteye.com/news/30731)
