---
title: webpack-6配置问题
date: 2018-01-21 22:11:34
categories: 前端自动化
tags: webpack
---


### 大问题

#### webpack-dev-server

1 入口文件与引入的静态文件不在一个目录怎么办

2 入口文件不是index.js

### 小参数问题
